package com.imangazaliev.notelin.bus

class NoteDeleteAction(val noteId: Long)
