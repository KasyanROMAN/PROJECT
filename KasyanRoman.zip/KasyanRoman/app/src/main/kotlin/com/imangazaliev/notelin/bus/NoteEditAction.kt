package com.imangazaliev.notelin.bus

class NoteEditAction(val noteId: Long)
