package com.imangazaliev.notelin.mvp.model

import com.reactiveandroid.annotation.Database

@Database(name = "AppDatabase", version = 1)
class AppDatabase